---
description: Hướng dẫn chuyển ảnh đề thi thành file JSON để import vào EasyRevise
---

# Chuyển Ảnh Đề Thi → File Import JSON (EasyRevise)

## Tổng quan

Workflow này giúp bạn chuyển ảnh chụp đề thi (từ sách, in, hoặc PDF) thành file `.json` để import trực tiếp vào hệ thống EasyRevise.

## Dữ liệu được lưu ở đâu?

- **File chính**: `data/exams.json` — lưu tất cả đề thi và câu hỏi
- **Backup**: Export từ Admin → tải file `.json` về máy
- **Format**: `easyrevise-exam-v1`

## Quy trình chuyển ảnh → Import

### Bước 1: Chụp ảnh đề thi
- Chụp rõ ràng, đủ sáng
- Mỗi trang 1 ảnh, theo thứ tự

### Bước 2: Gửi ảnh cho AI (Antigravity/Claude/ChatGPT)
Sử dụng prompt sau:

```
Hãy đọc các ảnh đề thi tiếng Anh dưới đây và chuyển thành file JSON theo format EasyRevise.

Format mong muốn:
{
  "_format": "easyrevise-exam-v1",
  "exam": {
    "title": "Tên đề thi",
    "subject": "Tiếng Anh X",
    "year": "2025-2026",
    "sections": [
      {
        "title": "Tên phần (VD: I. LANGUAGE FOCUS)",
        "instruction": "Hướng dẫn (VD: Choose the correct answer...)",
        "type": "multiple-choice",
        "questions": [
          {
            "id": 1,
            "question": "Nội dung câu hỏi...",
            "options": ["A. ...", "B. ...", "C. ...", "D. ..."],
            "correctAnswer": 0,
            "explanation": "Giải thích tại sao đúng",
            "expansion": "Kiến thức mở rộng liên quan"
          }
        ]
      }
    ]
  }
}

Các loại section type hỗ trợ:
- "multiple-choice": Trắc nghiệm A/B/C/D
- "reading": Đọc hiểu (có thêm trường "passage")
- "writing-choice": Chọn câu đồng nghĩa
- "writing-essay": Viết luận (có trường "prompt", "cues", "sampleAnswer")

Lưu ý:
- correctAnswer: 0 = A, 1 = B, 2 = C, 3 = D
- Mỗi section phải có trường "type"
- Với phần reading, thêm trường "passage" chứa đoạn văn
- Với phần essay, thêm "prompt", "cues" (array), "sampleAnswer"
- Giải thích phải chi tiết, dễ hiểu cho học sinh
- Mở rộng kiến thức liên quan đến câu hỏi
```

### Bước 3: Kiểm tra file JSON
- Đảm bảo JSON hợp lệ (dùng jsonlint.com nếu cần)
- Kiểm tra `_format` phải là `"easyrevise-exam-v1"`
- Kiểm tra các `correctAnswer` đúng (0-3)

### Bước 4: Import vào EasyRevise
1. Mở Admin Panel: `http://localhost:3000/admin`
2. Bấm **"Import đề JSON"**
3. Chọn file `.json` vừa tạo
4. Đề thi sẽ xuất hiện trong danh sách

## Ví dụ file JSON hoàn chỉnh

```json
{
  "_format": "easyrevise-exam-v1",
  "exam": {
    "title": "Đề Cương Cuối Kỳ I - Anh 9",
    "subject": "Tiếng Anh 9",
    "year": "2025-2026",
    "sections": [
      {
        "title": "I. PRONUNCIATION",
        "instruction": "Choose the word whose underlined part is pronounced differently.",
        "type": "multiple-choice",
        "questions": [
          {
            "id": 1,
            "question": "Choose the word whose underlined part is pronounced differently.",
            "options": ["heat", "meat", "great", "seat"],
            "correctAnswer": 2,
            "explanation": "'great' phát âm là /eɪ/, còn các từ còn lại phát âm /iː/.",
            "expansion": "Nhóm 'ea' thường phát âm /iː/: beat, clean, dream. Ngoại lệ: great, break, steak → /eɪ/"
          }
        ]
      },
      {
        "title": "II. READING",
        "instruction": "Read the passage and choose the best answer.",
        "type": "reading",
        "passage": "Nội dung đoạn văn ở đây...",
        "questions": [
          {
            "id": 10,
            "question": "What is the main idea of the passage?",
            "options": ["Option A", "Option B", "Option C", "Option D"],
            "correctAnswer": 1,
            "explanation": "Đáp án B vì...",
            "expansion": "Kỹ năng đọc hiểu: Để tìm main idea..."
          }
        ]
      },
      {
        "title": "III. WRITING",
        "instruction": "Write a paragraph (100-120 words)",
        "type": "writing-essay",
        "prompt": "Write about your favorite hobby and why you enjoy it.",
        "cues": [
          "1. What / your hobby?",
          "2. How long / you / do it?",
          "3. Why / you / enjoy?"
        ],
        "sampleAnswer": "My favorite hobby is reading books...",
        "explanation": "Bài mẫu sử dụng cấu trúc topic sentence + supporting details..."
      }
    ]
  }
}
```

## Tips

- **Batch import**: Có thể gửi nhiều ảnh cùng lúc cho AI
- **Export backup**: Luôn export đề đã hoàn thiện để backup  
- **Chỉnh sửa**: Sau khi import, có thể sửa trực tiếp trong Admin Panel
- **Lưu trữ**: File `data/exams.json` là database, nên backup thường xuyên
